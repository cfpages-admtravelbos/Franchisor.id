{{ ucfunc("put_docready_start") }}
    
    var objCarousel = jQuery('#{{uc_id}}');
    
    function initCarousel(){  
      
      objCarousel.owlCarousel({
        items: 1,
        loop: {{loop}},
        navRewind:{{navigation_rewind}},
        setActiveClassOnMobile:{{active_on_mobile}},
        changeItemOnClick:{{scroll_on_click}},
        paddingType: "{{stage_padding_type}}", 
        center:{{center}},
        autoplayTimeout: {{autoplay_timeout}},
        autoplayHoverPause: {{autoplay_hover_pause}},
        smartSpeed: {{transition_speed}},
        navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],		
        nav: {{show_arrows}},
        rtl: {{rtl}},
        navigation:true,
        mouseDrag:{{mouse_drag}},
        touchDrag:{{touch_drag}},  
        shuffle:{{shuffle}},
        autoplay: {{autoplay}},              
        mousewheelControl: {{enable_mouse_wheel_control}},
        scrollToHead:{{scroll_to_head}},
        scrollToHeadOffset: {{scroll_to_head_offset}},
        responsive : {
          0 : {
            items:{{number_of_items_mobile}},
            slideBy: {{slides_to_scroll_mobile}},
            scrollToHeadForceOnMobile: {{scroll_to_head_forced_on_mobile}}, 
            margin: {{margin_between_items_mobile}},  
            {% if center == "false" %}
            dotsEach: {{show_dots_each_x_item_mobile}},
            {% endif %}
            
            {% if stage_padding_type != "none" %}
            stagePadding: {{stagepadding_mobile}},
            {% endif %}	
          },
          768 : {
            items:{{number_of_items_tablet}},
            slideBy: {{slides_to_scroll_tablet}},
            margin: {{margin_between_items_tablet}},  
            {% if center == "false" %}
            dotsEach: {{show_dots_each_x_item_tablet}},
            {% endif %}	
            
            {% if stage_padding_type != "none" %}
            stagePadding: {{stagepadding_tablet}},
            {% endif %}	        
          },
          980 : {
            items:{{number_of_items}},
            slideBy: {{slides_to_scroll}},
            margin: {{margin_between_items}},  
            {% if center == "false" %} 
            dotsEach: {{show_dots_each_x_item}},
            {% endif %}
            
            {% if stage_padding_type != "none" %}
            stagePadding: {{stagepadding}},
            {% endif %}        
          } 
        }
      });
      
    }
    
    initCarousel();
    
    {{ucfunc("put_remote_parent_js","objCarousel")}}  
    
    objCarousel.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){
      
      objCarousel.trigger("replace.owl.carousel",htmlItems);
      objCarousel.trigger("refresh.owl.carousel");       
      
    });
    
    
{{ ucfunc("put_docready_end") }}