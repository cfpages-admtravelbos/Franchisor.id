<div class="uc_image_carousel_container_holder uc_carousel_item ue-item">
  
  {% if show_image == "true" %}
    <div class="uc_image_carousel_placeholder {{image_hover_animation}}">
      {% if image_link == "lightbox" %}<a href="{{item.post.image}}" style="display:block;" data-lity>{% endif %}
      {% if image_link == "post" %}<a href="{{item.post.link}}" style="display:block;">{% endif %}
        {% if item.post.image is empty %}
          <img src="{{uc_assets_url}}/placeholder.jpg"> 
        {% else %} 
          <img src="{{item.post.image}}" {{item.post.image_attributes|raw}} alt="{{item.post.image_alt}}" title="{{item.post.image_title}}"> 
        {% endif %}	
        <div class="ue_pos_carousel_image_overlay"></div>
      {% if image_link == "post" %}</a>{% endif %}
      {% if image_link == "lightbox" %}</a>{% endif %}
    </div>{# end uc_image_carousel_placeholder #}{##}
  {% endif %}{# end show_image == "true" #}{##}

  
  {% if show_content == "true" %}
    <div class="uc_image_carousel_content" >
      <div class="uc_image_carousel_content_holder">

        {% if show_category == "cat" or show_category == "bytax" or show_category == "lastlevel" %}          
          {% if show_category == "cat" %}
            {% set arrcats = item.post.categories %}
          {% elseif show_category == "lastlevel" %}
            {% set arrcats =  getPostTerms(item.post.id, cat_tax, false,"last_level",cat_maxterms) %}           
          {% else %}
            {% set arrcats =  getPostTerms(item.post.id, cat_tax, false,"",cat_maxterms) %}        		
          {% endif %}        
          <div class="ue-grid-item-category">
            {% for cat in arrcats %}
              <a href="{{cat.link}}">{{cat.name|raw}}</a>
            {% endfor %}
          </div>        
        {% elseif show_category == "main" %}        
          <div class="ue-grid-item-category">
            <a href="{{item.post.category_link}}">{{item.post.category_name|raw}}</a>
          </div>        	
        {% endif %}                   

        {% if show_title == "true" %}
          {% if title_link == "true" %}<a href="{{item.post.link}}">{% endif %}
            <{{title_html_tag}} class="uc_post_title">{{item.post.title|ucsafe|raw}}</{{title_html_tag}}>
          {% if title_link == "true" %}</a>{% endif %}
        {% endif %}          

        <div class="ue-meta-data">
          {% if show_date == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{date_icon_html|raw}}</span> {{text_before_date|raw}} {{item.post.date|ucdate(date_format)|raw}}</div>{% endif %}
          {% if show_time == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{time_icon_html|raw}}</span> {{text_before_time|raw}} {{item.post.date|ucdate(time_format)|raw}}</div>{% endif %}
          {% if show_time_ago == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{time_ago_icon_html|raw}}</span> {{text_before_time_ago|raw}} {{item.post.date|ucdate("time_ago")|raw}}</div>{% endif %}            
          {% if show_comments == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{comments_icon_html|raw}}</span> {{text_before_comments|raw}}  {% set num_comments = ucfunc("get_num_comments", item.post.id) %} {{num_comments}} </div>{% endif %}
          {% if show_author == "true" %}<div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{author_icon_html|raw}}</span> {{text_before_author|raw}} {% set author = getPostAuthor(item.post.author_id) %}<a href="{{author.url_posts}}"> {{author.name}} </a></div>{% endif %}            

          {% if show_custom_meta_one == "true" %}
            {% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_one)%} 
            <div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_one_html|raw}}</span> {{custom_meta_text_before_one|raw}} {{custom_field_value|raw}}</div>
          {% endif %}

          {% if show_custom_meta_two == "true" %}
            {% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_two)%} 
            <div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_two_html|raw}}</span> {{custom_meta_text_before_two|raw}} {{custom_field_value|raw}}</div>
          {% endif %}

          {% if show_custom_meta_three == "true" %}
            {% set custom_field_value = ucfunc("get_post_custom_field", item.post.id,custom_meta_name_three)%} 
            <div class="ue-grid-item-meta-data"><span class="ue-grid-item-meta-data-icon">{{custom_meta_icon_three_html|raw}}</span> {{custom_meta_text_before_three|raw}} {{custom_field_value|raw}}</div>
          {% endif %}

          {% if show_post_image_caption == "true" %}<div class="ue-grid-item-meta-data"> {{item.post.image_caption}}</div>{% endif %}           

          {% if debug_meta_fields == "true" %}
            <div class="ue-debug-meta">
              {{ucfunc("put_post_meta_debug",item.post.id)}}
            </div>
          {% endif %}  

        </div>{# end ue-meta-data #}{##}

        {% if show_intro == "true" %}<div class="uc_paragraph" >{{item.post.intro_full|truncate(intro_number_of_characters)|raw}}</div>{% endif %}
		{% if show_post_full_content == "true" %}<div class="uc_paragraph">{{ucfunc("put_post_content", item.post.id, item.post.content)}}</div>{% endif %}
      </div>{# end uc_image_carousel_content_holder #}{##}

      {% if show_button == "true" %}    
        <div class="ue-item-btn-holder">   
          <a target="{{open_link_in_new_tab}}" href="{{item.post.link}}" class="uc_more_btn ue-dynamic-popup-single {{item.post.dynamic_popup_link_class}}" {{item.post.dynamic_popup_link_attributes|raw}}>{{read_txt|raw}}{% if show_button_icon == "true" %}{{button_icon_html|raw}}{% endif %}</a>
        </div>    
      {% endif %}
    </div>{# end uc_image_carousel_content #}{##}
  {% endif %}{# end show_content == "true" #}{##}
  
  {% if link_complete_item == "true" %}
  	<a class="ue-link-all-item ue-dynamic-popup-single {{item.post.dynamic_popup_link_class__complete}}" {{item.post.dynamic_popup_link_attributes__complete|raw}} style="opacity:0;" target="{{link_type}}">{{item.post.title|raw}}</a>
  {% endif %}
  
</div>